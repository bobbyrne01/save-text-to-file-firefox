The Save Text to File extension does not gather any user data.

Nor does the add-on send any information to the add-on author or any third-party.

The settings data for the extension is stored only within the User's sync storage in Firefox, for the purposes of keeping a User's extension in sync across their devices.

There is no advertising and no analytics.
